let nome = document.querySelector('#idNome')
let span = document.querySelector('#acao')

nome.addEventListener('focus', ()=>{
    nome.style.outlineColor = 'blue'
    span.innerHTML = 'o usuário acessou o campo!'
})
nome.addEventListener('blur', ()=>{
    nome.style.borderColor = 'red'
    span.innerHTML = 'O usuario saiu do campo'
})

let range = document.getElementById('idBarra')
let valor = document.getElementById('idValor')

range.addEventListener('change', ()=>{
    valor.innerHTML = range.value
})

let form = document.querySelector('idForm')

form.addEventListener('submit', ()=>{
    alert('Obrigado por preencher a nossa pesquisa!')
})